package com.zhongxing.server;

import java.util.Date;
import java.util.List;

import com.zhongxing.entity.Sign;

public interface ShowOnMonth {
	List<Sign> showTable(Integer id,Date date);
}
