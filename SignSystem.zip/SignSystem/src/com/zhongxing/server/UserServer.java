package com.zhongxing.server;

public interface UserServer {
	
}
