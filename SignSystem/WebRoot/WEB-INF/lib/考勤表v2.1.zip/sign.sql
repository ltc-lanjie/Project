/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : signsys

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2017-07-11 17:12:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sign
-- ----------------------------
DROP TABLE IF EXISTS `sign`;
CREATE TABLE `sign` (
  `uid` int(40) DEFAULT NULL COMMENT '员工编号',
  `checkintime` time DEFAULT NULL COMMENT '上班签到时间',
  `offcalltime` time DEFAULT NULL COMMENT '下班签到时间',
  `signdate` date DEFAULT NULL COMMENT '签到日期',
  `signstatus` int(10) DEFAULT NULL COMMENT '签到状况'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sign
-- ----------------------------
INSERT INTO `sign` VALUES ('1', '09:24:24', '09:24:28', '2017-07-05', null);
