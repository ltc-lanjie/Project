/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : signsys

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2017-07-11 17:12:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uname` varchar(255) DEFAULT NULL COMMENT '用户名',
  `uid` int(40) NOT NULL AUTO_INCREMENT COMMENT 'id，主键',
  `upassword` varchar(255) DEFAULT NULL COMMENT '密码',
  `utelphone` varchar(255) DEFAULT NULL COMMENT '电话',
  `upicture` varchar(255) DEFAULT NULL COMMENT '头像图片',
  `ubirthdate` date DEFAULT NULL COMMENT '出生日期',
  `usex` int(10) DEFAULT NULL COMMENT '性别',
  `utype` varchar(255) DEFAULT NULL COMMENT '用户类型',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('zhangsan', '1', '123456', '13111111111', '123.jpg', '2017-01-01', '2', 'manager');
INSERT INTO `user` VALUES ('lisi', '2', '123', '13973894344', '213.jpg', '2017-03-08', '0', 'manager');
INSERT INTO `user` VALUES ('wangwwu', '3', '123', '13000000000', '12.png', '2017-07-11', '1', 'manager');
