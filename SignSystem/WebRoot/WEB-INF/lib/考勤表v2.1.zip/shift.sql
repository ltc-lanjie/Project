/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : signsys

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2017-07-11 17:12:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for shift
-- ----------------------------
DROP TABLE IF EXISTS `shift`;
CREATE TABLE `shift` (
  `sid` int(40) NOT NULL COMMENT '班次编号',
  `scheckin` time DEFAULT NULL COMMENT '上班时间',
  `soffcall` time DEFAULT NULL COMMENT '下班时间',
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shift
-- ----------------------------
INSERT INTO `shift` VALUES ('1', '09:00:00', '12:00:00');
INSERT INTO `shift` VALUES ('2', '16:40:38', '16:40:41');
