/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : signsys

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2017-07-11 17:12:29
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for scheduling
-- ----------------------------
DROP TABLE IF EXISTS `scheduling`;
CREATE TABLE `scheduling` (
  `uid` int(11) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  KEY `uid` (`uid`),
  KEY `sid` (`sid`),
  CONSTRAINT `sid` FOREIGN KEY (`sid`) REFERENCES `shift` (`sid`),
  CONSTRAINT `uid` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of scheduling
-- ----------------------------
INSERT INTO `scheduling` VALUES ('2', '1');
INSERT INTO `scheduling` VALUES ('3', '1');
INSERT INTO `scheduling` VALUES ('1', '2');
INSERT INTO `scheduling` VALUES ('2', '1');
INSERT INTO `scheduling` VALUES ('1', '2');
