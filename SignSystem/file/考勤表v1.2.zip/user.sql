/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : signsys

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2017-07-11 09:53:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uname` varchar(255) DEFAULT NULL COMMENT '用户名',
  `uid` int(40) NOT NULL COMMENT 'id，主键',
  `upassword` varchar(255) DEFAULT NULL COMMENT '密码',
  `utelphone` varchar(255) DEFAULT NULL COMMENT '电话',
  `upicture` varchar(255) DEFAULT NULL COMMENT '头像图片',
  `ubirthdate` date DEFAULT NULL COMMENT '出生日期',
  `usex` int(10) DEFAULT NULL COMMENT '性别',
  `utype` varchar(255) DEFAULT NULL COMMENT '用户类型',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
